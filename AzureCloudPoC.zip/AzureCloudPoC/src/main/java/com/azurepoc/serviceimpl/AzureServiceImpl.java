package com.azurepoc.serviceimpl;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import javax.naming.ServiceUnavailableException;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Service;

import com.azurepoc.service.AzureService;
import com.microsoft.aad.adal4j.AuthenticationContext;
import com.microsoft.aad.adal4j.AuthenticationResult;
import com.microsoft.aad.adal4j.ClientCredential;
import com.microsoft.azure.AzureEnvironment;
import com.microsoft.azure.CloudException;
import com.microsoft.azure.credentials.ApplicationTokenCredentials;
import com.microsoft.azure.management.Azure;
import com.microsoft.rest.LogLevel;

@Service
public class AzureServiceImpl implements AzureService {

	private static String tenant = "c1687751-ddaf-4904-b9e3-c3626f2b81d5";
	private static String client = "6a0f4f1d-a426-44e5-a28c-96395e29edff";
	private static String key = "YPmLrWGprOKn2ZEP8yG1ChjuDkRsWaanbb+BhtYlktE=";
	private static String subscriptionId = "850ca8ad-0834-4749-8135-038468121225";

	private final static String AUTHORITY = "https://login.windows.net/c1687751-ddaf-4904-b9e3-c3626f2b81d5";

	@Override
	public String getSearchResult() {

		JSONObject wrapperObj = new JSONObject();
		JSONArray jsonArray = new JSONArray();

		ArrayList nameList = new ArrayList<>();
		ArrayList typeList = new ArrayList<>();

		// Making the connection with COSMos DB account
		/*
		 * ApplicationTokenCredentials credentials = new
		 * ApplicationTokenCredentials(client, tenant, key, AzureEnvironment.AZURE);
		 */

		try

		{
			AuthenticationResult result = getAccessTokenFromUserCredentials();
			System.out.println("Access Token - " + result.getAccessToken());
			HttpClient client = new DefaultHttpClient();

			HttpGet request = new HttpGet("https://management.azure.com/subscriptions/" + subscriptionId
					+ "/resourceGroups/MultiCloudSearch/providers/Microsoft.DataCatalog/catalogs?api-version=2016-03-30");
			request.addHeader("Authorization", "Bearer " + result.getAccessToken());
			HttpResponse response = client.execute(request);
			BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
			String line = "";
			while ((line = rd.readLine()) != null) {
				System.out.println(line);
			}

			/*
			 * Azure azure =
			 * Azure.configure().withLogLevel(LogLevel.NONE).authenticate(credentials)
			 * .withSubscription(subscriptionId);
			 * 
			 * System.out.println("azure :: " + azure.getCurrentSubscription());
			 * 
			 * URL line_api_url = new
			 * URL("https://ads.line.me/api/v1.0/authority_delegations/get");
			 * 
			 * Get a data catalog
			 * https://management.azure.com/subscriptions/<subscriptionId>/resourceGroups/<
			 * resouceGroup>/providers/Microsoft.DataCatalog/catalogs/<catalogName>
			 * 
			 * List all data catalog
			 * https://management.azure.com/subscriptions/<subscriptionId>/resourceGroups/<
			 * resouceGroup>/providers/Microsoft.DataCatalog/catalogs
			 */
		} catch (CloudException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return wrapperObj.toString();
	}

	private static AuthenticationResult getAccessTokenFromUserCredentials() throws Exception {
		AuthenticationContext context = null;
		AuthenticationResult result = null;
		ExecutorService service = null;
		try {
			service = Executors.newFixedThreadPool(1);
			context = new AuthenticationContext(AUTHORITY, false, service);
			/*
			 * Replace {client_id} with ApplicationID and {password} with password that were
			 * used to create Service Principal above.
			 */
			
			ClientCredential credential = new ClientCredential(client, key);
			Future<AuthenticationResult> future = context.acquireToken("https://management.azure.com/", credential,
					null);
			result = future.get();
		} finally {
			service.shutdown();
		}
		if (result == null) {
			throw new ServiceUnavailableException("authentication result was null");
		}
		return result;
	}
}
