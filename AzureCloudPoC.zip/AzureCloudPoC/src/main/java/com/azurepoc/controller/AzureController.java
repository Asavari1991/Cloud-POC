package com.azurepoc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.azurepoc.service.AzureService;

@RestController
@CrossOrigin
@RequestMapping(value = "/azure")
public class AzureController {

	@Autowired
	private AzureService service;

	@RequestMapping(value = "/search", method = RequestMethod.GET)
	public String getSearchResult() {
		System.out.println("function called");

		String result = service.getSearchResult();

		return result;
	}

}
