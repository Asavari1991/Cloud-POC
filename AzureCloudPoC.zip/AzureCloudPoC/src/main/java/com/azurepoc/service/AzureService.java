package com.azurepoc.service;

import org.springframework.stereotype.Service;

@Service
public interface AzureService {

	public String getSearchResult();

}
