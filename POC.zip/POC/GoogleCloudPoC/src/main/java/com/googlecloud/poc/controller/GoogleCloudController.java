package com.googlecloud.poc.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URISyntaxException;
import java.security.GeneralSecurityException;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeRequestUrl;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.googleapis.testing.auth.oauth2.MockTokenServerTransport;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.Json;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.gson.GsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.client.util.store.FileDataStoreFactory;
import com.google.api.services.bigquery.Bigquery;
import com.google.api.services.bigquery.Bigquery.Tables;
import com.google.api.services.bigquery.BigqueryScopes;
import com.google.api.services.storage.StorageScopes;
import com.google.auth.http.HttpTransportFactory;
import com.google.auth.oauth2.AccessToken;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.auth.oauth2.ServiceAccountCredentials;
import com.google.cloud.TransportOptions;
import com.google.cloud.bigquery.BigQuery;
import com.google.cloud.bigquery.BigQueryOptions;
import com.google.cloud.bigquery.Dataset;
import com.google.cloud.bigquery.Table;
import com.google.cloud.http.HttpTransportOptions;
import com.googlecloud.poc.service.GoogleCloudService;

@RestController
@CrossOrigin
@RequestMapping(value = "/google")
public class GoogleCloudController {

	@Autowired
	private GoogleCloudService service;

	@RequestMapping(value = "metadata", method = RequestMethod.GET)
	public String getMetadataResult(HttpServletResponse response) throws URISyntaxException, IOException {

		String result = service.getSearchResult();

		return result;
	}

	@RequestMapping(value = "/search", method = RequestMethod.GET)
	public String getSearchResult(HttpServletResponse response) throws IOException {

		String clientId = "800354553094-suan5j2dggotplh33cjl0ie42o8neror.apps.googleusercontent.com";
		String redirectUrl = "https://www.googleapis.com/bigquery/v2/projects/metadataproject-226501/datasets/sensordata/tables/Person";
		String scope = "https://www.googleapis.com/auth/cloud-platform";
		System.out.println("function called");

		String link = new GoogleAuthorizationCodeRequestUrl(clientId, redirectUrl, Arrays.asList(
				"https://www.googleapis.com/auth/userinfo.email", "https://www.googleapis.com/auth/userinfo.profile"))
						.setState("/profile").build();

		String url = "https://accounts.google.com/o/oauth2/v2/auth?" + "scope=" + scope + "&" + "access_type=offline&"
				+ "include_granted_scopes=true&" + "redirect_uri=http%3A%2F%2Foauth2.example.com%2Fcallback&"
				+ "response_type=code&" + "client_id=" + clientId;

		response.sendRedirect(link);

		/*
		 * String url = new GoogleBrowserClientRequestUrl(clientId, redirectUrl,
		 * Arrays.asList(scope)).build();
		 */

		return service.getSearchResult();

	}
	
	@RequestMapping(value = "/tables", method = RequestMethod.GET)
	public String getTablesList()
	{
		System.out.println("function called");
		
		String result = service.getTablesList();
		
		return result;
	}
	
	@RequestMapping(value = "/tableMetadata", method = RequestMethod.GET)
	public String getTableMetadata(@RequestParam(value = "table") String table, @RequestParam(value = "dataset") String dataset)
	{
		System.out.println("getTableMetadata function called");
		
		String result = service.getTableMetadata(table, dataset);
		
		return result;
	}

}
