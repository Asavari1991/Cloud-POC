package com.googlecloud.poc.service;

import org.springframework.stereotype.Service;

@Service
public interface GoogleCloudService {

	public String getSearchResult();

	public String getTablesList();

	public String getTableMetadata(String table, String dataset);

}
