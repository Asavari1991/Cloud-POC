package com.googlecloud.poc.model;

public class GCPResponseTO {

	private String schema;
	private String fields;
	private String name;
	private String type;
	private String mode;
	private String creationTime;
	private String location;
	
	public GCPResponseTO() {
		super();
	}

	public GCPResponseTO(String schema, String fields, String name, String type, String mode, String creationTime,
			String location) {
		super();
		this.schema = schema;
		this.fields = fields;
		this.name = name;
		this.type = type;
		this.mode = mode;
		this.creationTime = creationTime;
		this.location = location;
	}

	public String getSchema() {
		return schema;
	}

	public void setSchema(String schema) {
		this.schema = schema;
	}

	public String getFields() {
		return fields;
	}

	public void setFields(String fields) {
		this.fields = fields;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public String getCreationTime() {
		return creationTime;
	}

	public void setCreationTime(String creationTime) {
		this.creationTime = creationTime;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}
}
