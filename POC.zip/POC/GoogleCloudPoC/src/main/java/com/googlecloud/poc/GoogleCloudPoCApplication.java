package com.googlecloud.poc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GoogleCloudPoCApplication {

	public static void main(String[] args) {
		SpringApplication.run(GoogleCloudPoCApplication.class, args);
	}

}

