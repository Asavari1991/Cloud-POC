package com.googlecloud.poc.serviceimpl;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Arrays;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.stereotype.Service;

import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.googleapis.testing.auth.oauth2.MockTokenServerTransport;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.auth.oauth2.ServiceAccountCredentials;
import com.google.cloud.bigquery.BigQuery;
import com.google.cloud.bigquery.BigQueryOptions;
import com.google.cloud.bigquery.Dataset;
import com.google.cloud.bigquery.DatasetId;
import com.google.cloud.bigquery.Table;
import com.googlecloud.poc.service.GoogleCloudService;

@Service
public class GoogleCloudServiceImpl implements GoogleCloudService {

	private static final String CLIENTSECRETS_LOCATION = "C:\\eCLIPSE\\service_account.json";

	final MockTokenServerTransport transport = new MockTokenServerTransport();

	static GoogleClientSecrets clientSecrets = loadClientSecrets();

	@Override
	public String getSearchResult() {

		JSONObject wrapperObj = new JSONObject();
		JSONArray array = new JSONArray();

		ArrayList nameList = new ArrayList<>();
		ArrayList modeList = new ArrayList<>();
		ArrayList typeList = new ArrayList<>();
		try {
			GoogleCredentials credentials;
			try (FileInputStream serviceAccountStream = new FileInputStream(CLIENTSECRETS_LOCATION)) {

				credentials = ServiceAccountCredentials.fromStream(serviceAccountStream);

				if (credentials.createScopedRequired()) {
					credentials.createScoped(Arrays.asList("https://www.googleapis.com/auth/cloud-platform.read-only",
							"https://www.googleapis.com/auth/cloud-platform",
							"https://www.googleapis.com/auth/bigquery")).refreshAccessToken();
				}

			}

			// Instantiate a client.
			BigQuery bigquery = BigQueryOptions.newBuilder().setCredentials(credentials).build().getService();
			// Use the client.
			credentials.getAccessToken();
			System.out.println("credentials " + credentials);

			DatasetId datasetId;
			String datasetTemp = "";
			String tableTemp = "";
			Table table = null;

			for (Dataset dataset : bigquery.listDatasets().iterateAll()) {
				System.out.printf("%s%n", dataset.getDatasetId().getDataset());
				datasetId = dataset.getDatasetId();
				datasetTemp = dataset.getDatasetId().getDataset();

				for (Table tempTable : bigquery.listTables(datasetId).iterateAll()) {
					System.out.println("tempTable :: " + tempTable);
					tableTemp = tempTable.getTableId().getTable();
					System.out.println("tableTemp :: " + tableTemp);
					table = bigquery.getTable(datasetTemp, tableTemp);
					System.out.println("table : " + table);

					for (int i = 0; i < table.getDefinition().getSchema().getFields().size(); i++) {
						System.out.println("table startc ::");
						String tableName = table.getDefinition().getSchema().getFields().get(i).getName().toString();
						String modeName = table.getDefinition().getSchema().getFields().get(i).getMode().toString();
						String typeName = table.getDefinition().getSchema().getFields().get(i).getType().toString();

						nameList.add(tableName);
						modeList.add(modeName);
						typeList.add(typeName);

					}
					array = new JSONArray();
					for (int j = 0; j < nameList.size(); j++) {

						JSONObject item = new JSONObject();

						item.put("name", nameList.get(j));
						item.put("mode", modeList.get(j));
						item.put("type", typeList.get(j));
						array.put(item);
					}

					JSONObject mainObj = new JSONObject();
					mainObj.put("fields", array);

					wrapperObj.put("schema", mainObj);

					System.out.println("mainObj  :: " + mainObj);
				}
			}
			// Table table = bigquery.getTable(datasetId.getDataset(), "Person");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("");
		}
		return wrapperObj.toString();
	}

	private static GoogleClientSecrets loadClientSecrets() {
		try {
			InputStream inputStream = new FileInputStream(CLIENTSECRETS_LOCATION);
			Reader reader = new InputStreamReader(inputStream);
			GoogleClientSecrets clientSecrets = GoogleClientSecrets.load(new JacksonFactory(), reader);
			return clientSecrets;
		} catch (Exception e) {
			System.out.println("Could not load client secrets file " + CLIENTSECRETS_LOCATION);
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public String getTablesList() {
		// https://www.googleapis.com/bigquery/v2/projects/projectId/datasets/datasetId/tables

		DatasetId datasetId;
		String datasetTemp = "";
		String tableTemp = "";
		Table table = null;
		BigQuery bigquery = getbigqueryClient();
		JSONArray jsonArray = new JSONArray();
		JSONObject jsonObj = new JSONObject();
		ArrayList tableNameList = new ArrayList<>();
		for (Dataset dataset : bigquery.listDatasets().iterateAll()) {
			System.out.printf("%s%n", dataset.getDatasetId().getDataset());
			datasetId = dataset.getDatasetId();
			datasetTemp = dataset.getDatasetId().getDataset();

			for (Table tempTable : bigquery.listTables(datasetId).iterateAll()) {
				System.out.println("tempTable :: " + tempTable);
				tableTemp = tempTable.getTableId().getTable();
				System.out.println("tableTemp :: " + tableTemp);

				tableNameList.add(tableTemp);
			}
			try {

				jsonArray = new JSONArray();
				JSONObject mainObj = new JSONObject();
				for (int k = 0; k < tableNameList.size(); k++) {

					JSONObject jsonItem = new JSONObject();

					jsonItem.put("name", tableNameList.get(k));
					jsonItem.put("dataset", datasetId.toString());
					System.out.println("jsonItem:: " + jsonItem);

					jsonArray.put(jsonItem);

				}
				System.out.println("jsonArray  :: " + jsonArray);
				jsonObj.put("tableList", jsonArray);
			} catch (

			JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		return jsonObj.toString();
	}

	@Override
	public String getTableMetadata(String table, String dataset) {
		BigQuery bigquery = getbigqueryClient();

		JSONObject wrapperObj = new JSONObject();
		JSONArray array = new JSONArray();

		ArrayList nameList = new ArrayList<>();
		ArrayList modeList = new ArrayList<>();
		ArrayList typeList = new ArrayList<>();

		try {

			Table tempTable = bigquery.getTable(dataset, table);
			System.out.println("table : " + table);

			for (int i = 0; i < tempTable.getDefinition().getSchema().getFields().size(); i++) {
				System.out.println("table startc ::");
				String tableName = tempTable.getDefinition().getSchema().getFields().get(i).getName().toString();
				String modeName = tempTable.getDefinition().getSchema().getFields().get(i).getMode().toString();
				String typeName = tempTable.getDefinition().getSchema().getFields().get(i).getType().toString();

				nameList.add(tableName);
				modeList.add(modeName);
				typeList.add(typeName);

			}
			array = new JSONArray();
			for (int j = 0; j < nameList.size(); j++) {

				JSONObject item = new JSONObject();

				item.put("name", nameList.get(j));
				item.put("mode", modeList.get(j));
				item.put("type", typeList.get(j));
				array.put(item);
			}

			JSONObject mainObj = new JSONObject();
			mainObj.put("fields", array);

			wrapperObj.put("schema", mainObj);

			System.out.println("mainObj  :: " + mainObj);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("");
		}

		return wrapperObj.toString();

	}

	public BigQuery getbigqueryClient() {
		GoogleCredentials credentials;
		BigQuery bigquery = null;
		try (FileInputStream serviceAccountStream = new FileInputStream(CLIENTSECRETS_LOCATION)) {

			credentials = ServiceAccountCredentials.fromStream(serviceAccountStream);

			if (credentials.createScopedRequired()) {
				credentials.createScoped(Arrays.asList("https://www.googleapis.com/auth/cloud-platform.read-only",
						"https://www.googleapis.com/auth/cloud-platform", "https://www.googleapis.com/auth/bigquery"))
						.refreshAccessToken();
			}

			// Instantiate a client.
			bigquery = BigQueryOptions.newBuilder().setCredentials(credentials).build().getService();

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bigquery;
	}
}
