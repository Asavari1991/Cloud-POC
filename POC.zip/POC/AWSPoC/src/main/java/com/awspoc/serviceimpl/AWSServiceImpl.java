package com.awspoc.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.glue.AWSGlue;
import com.amazonaws.services.glue.AWSGlueClientBuilder;
import com.amazonaws.services.glue.model.Column;
import com.amazonaws.services.glue.model.GetTableRequest;
import com.amazonaws.services.glue.model.GetTableResult;
import com.amazonaws.services.glue.model.GetTablesRequest;
import com.amazonaws.services.glue.model.GetTablesResult;
import com.awspoc.service.AWSService;
import com.awspoc.util.ConnectAWSClient;

@Service
public class AWSServiceImpl implements AWSService {

	private static final String ACCESS_KEY = "AKIAINW2D2BCX673VAIA";
	private static final String SECRET_KEY = "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";

	@Override
	public String getTablesList() {

		System.out.println("calling...........");
		AWSGlue awsGlueClient = getAWSClient();

		GetTablesRequest tablesReq = new GetTablesRequest().withDatabaseName("labdata");

		System.out.println("tablesReq :: " + tablesReq);

		GetTablesResult tableResults = awsGlueClient.getTables(tablesReq);

		System.out.println("tableResults :: " + tableResults.toString());

		JSONArray jsonArray = new JSONArray();
		JSONObject jsonObj = new JSONObject();

		ArrayList tableNameList = new ArrayList<>();

		String databaseName = tablesReq.getDatabaseName();

		try {
			for (int i = 0; i < tableResults.getTableList().size(); i++) {
				String tableName = tableResults.getTableList().get(i).getName();
				tableNameList.add(tableName);
			}
			jsonArray = new JSONArray();
			JSONObject mainObj = new JSONObject();
			for (int k = 0; k < tableNameList.size(); k++) {

				JSONObject jsonItem = new JSONObject();

				jsonItem.put("name", tableNameList.get(k));
				jsonItem.put("database", databaseName);
				System.out.println("jsonItem:: " + jsonItem);

				jsonArray.put(jsonItem);

			}
			System.out.println("jsonArray  :: " + jsonArray);
			jsonObj.put("tableList", jsonArray);
		} catch (

		JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return jsonObj.toString();
	}

	@Override
	public String getTableMetadata(String table, String database) {

		System.out.println("calling...........");
		AWSGlue awsGlueClient = getAWSClient();

		GetTableRequest tableReq = new GetTableRequest().withDatabaseName(database).withName(table);

		System.out.println("tableReq :: " + tableReq);
		JSONObject wrapperObj = new JSONObject();
		JSONArray jsonArray = new JSONArray();

		ArrayList nameList = new ArrayList<>();
		ArrayList typeList = new ArrayList<>();

		GetTableResult tabresults = awsGlueClient.getTable(tableReq);
		System.out.println("tabresults :: " + tabresults);

		try {
			List<Column> cols = tabresults.getTable().getStorageDescriptor().getColumns();

			for (int j = 0; j < cols.size(); j++) {
				String name = cols.get(j).getName();
				String type = cols.get(j).getType();
				nameList.add(name);
				typeList.add(type);

				System.out.println("name " + name);
			}

			jsonArray = new JSONArray();
			JSONObject mainObj = new JSONObject();
			for (int k = 0; k < nameList.size(); k++) {

				JSONObject jsonItem = new JSONObject();

				jsonItem.put("name", nameList.get(k));
				jsonItem.put("type", typeList.get(k));
				System.out.println("jsonItem:: " + jsonItem);

				jsonArray.put(jsonItem);

			}
			mainObj.put("FieldSchema", jsonArray);

			System.out.println("mainObj  :: " + mainObj);
			wrapperObj.put("cols", mainObj);

			System.out.println("wrapperObj  :: " + wrapperObj);

		} catch (

		JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return wrapperObj.toString();
	}

	@Override
	public String getSearchResult() {

		JSONObject wrapperObj = new JSONObject();
		JSONArray jsonArray = new JSONArray();

		ArrayList nameList = new ArrayList<>();
		ArrayList typeList = new ArrayList<>();

		BasicAWSCredentials awsCreds = new BasicAWSCredentials(ACCESS_KEY, SECRET_KEY);

		AWSGlue client = AWSGlueClientBuilder.standard().withCredentials(new AWSStaticCredentialsProvider(awsCreds))
				.withRegion(Regions.US_WEST_2).build();

		System.out.println("client : " + client.toString());

		GetTableRequest tableReq = new GetTableRequest().withDatabaseName("labdata")
				.withName("_environmentperson_sensor_data_csv");

		System.out.println("tableReq :: " + tableReq);

		GetTableResult tabresults = client.getTable(tableReq);
		System.out.println("tabresults :: " + tabresults);

		GetTablesRequest tablesReq = new GetTablesRequest().withDatabaseName("labdata");

		System.out.println("tablesReq :: " + tablesReq.getDatabaseName());

		GetTablesResult results = client.getTables(tablesReq);
		System.out.println("results :: " + results);
		try {
			for (int i = 0; i < results.getTableList().size(); i++) {
				List<Column> cols = results.getTableList().get(i).getStorageDescriptor().getColumns();

				for (int j = 0; j < cols.size(); j++) {
					String name = cols.get(j).getName();
					String type = cols.get(j).getType();
					nameList.add(name);
					typeList.add(type);

					System.out.println("name " + name);

				}

			}
			jsonArray = new JSONArray();
			JSONObject mainObj = new JSONObject();
			for (int k = 0; k < nameList.size(); k++) {

				JSONObject jsonItem = new JSONObject();

				jsonItem.put("name", nameList.get(k));
				jsonItem.put("type", typeList.get(k));
				System.out.println("jsonItem:: " + jsonItem);

				jsonArray.put(jsonItem);

			}
			mainObj.put("FieldSchema", jsonArray);

			System.out.println("mainObj  :: " + mainObj);
			wrapperObj.put("cols", mainObj);

			System.out.println("wrapperObj  :: " + wrapperObj);

		} catch (

		JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return wrapperObj.toString();
	}

	public AWSGlue getAWSClient() {

		BasicAWSCredentials awsCreds = new BasicAWSCredentials(ACCESS_KEY, SECRET_KEY);

		AWSGlue glueClient = AWSGlueClientBuilder.standard().withCredentials(new AWSStaticCredentialsProvider(awsCreds))
				.withRegion(Regions.US_WEST_2).build();

		System.out.println("glueClient : " + glueClient.toString());

		return glueClient;
	}

}
