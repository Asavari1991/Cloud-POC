package com.awspoc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AwsPoCApplication {

	public static void main(String[] args) {
		SpringApplication.run(AwsPoCApplication.class, args);
		
	}

}

