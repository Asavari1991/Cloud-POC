package com.awspoc.util;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.glue.AWSGlue;
import com.amazonaws.services.glue.AWSGlueClientBuilder;

public class ConnectAWSClient {
	

	private static final String ACCESS_KEY = "AKIAINW2D2BCX673VAIA";
	private static final String SECRET_KEY = "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";

	
	public AWSGlue getAWSClient()
	{

		BasicAWSCredentials awsCreds = new BasicAWSCredentials(ACCESS_KEY, SECRET_KEY);

		AWSGlue glueClient = AWSGlueClientBuilder.standard().withCredentials(new AWSStaticCredentialsProvider(awsCreds))
				.withRegion(Regions.US_WEST_2).build();

		System.out.println("glueClient : " + glueClient.toString());

		return glueClient;
	}

}
