package com.awspoc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.awspoc.service.AWSService;

@RestController
@CrossOrigin
@RequestMapping(value = "/aws")
public class AWSController {

	@Autowired
	private AWSService service;
	
	@RequestMapping(value = "/search", method = RequestMethod.GET)
	public String getSearchResult()
	{
		System.out.println("function called");
		
		String result = service.getSearchResult();
		
		return result;
	}
	
	@RequestMapping(value = "/tables", method = RequestMethod.GET)
	public String getTablesList()
	{
		System.out.println("function called");
		
		String result = service.getTablesList();
		
		return result;
	}
	
	@RequestMapping(value = "/tableMetadata", method = RequestMethod.GET)
	public String getTableMetadata(@RequestParam(value = "table") String table, @RequestParam(value = "database") String database)
	{
		System.out.println("getTableMetadata function called");
		
		String result = service.getTableMetadata(table, database);
		
		return result;
	}

}
