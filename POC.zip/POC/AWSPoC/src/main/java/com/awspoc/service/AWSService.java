package com.awspoc.service;

import org.springframework.stereotype.Service;

@Service
public interface AWSService {

	public String getSearchResult();

	public String getTablesList();

	public String getTableMetadata(String table, String database);

}
